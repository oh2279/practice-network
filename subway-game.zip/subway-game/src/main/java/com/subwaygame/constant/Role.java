package com.subwaygame.constant;

public enum Role {
    USER, ADMIN
}
