package com.subwaygame.constant;

public enum ItemSellStatus {
    SELL, SOLD_OUT
}
