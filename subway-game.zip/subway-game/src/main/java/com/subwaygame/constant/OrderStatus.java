package com.subwaygame.constant;

public enum OrderStatus {
    ORDER, CANCEL
}
