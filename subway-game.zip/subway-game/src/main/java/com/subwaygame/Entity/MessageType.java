package com.subwaygame.Entity;

public enum MessageType {
    ENTER,CHAT,LEAVE
}