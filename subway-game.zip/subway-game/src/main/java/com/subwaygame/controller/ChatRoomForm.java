package com.subwaygame.controller;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChatRoomForm {
    private String name;
}